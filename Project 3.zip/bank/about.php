<?php
    include "header.php";
    include "navbar.php";
    

?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="customer_home.css">
</head>

<body>
<h1>Welcome to Superteam bank LTD</h1>
<p><h2>Wants to read more? Come again another time.<br />Thank you!</h2></p>

</body>
</html>